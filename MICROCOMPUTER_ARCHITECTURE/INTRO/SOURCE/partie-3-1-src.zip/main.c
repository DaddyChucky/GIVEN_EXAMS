#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

int main(int argc, char** argv) {
   /* TODO: Écrivez votre version en langage C du programme. 
   Ce dernier devrait compiler et s’exécuter sans erreur, et ce, avec le même comportement et 
   le même résultat que le code en assembleur fourni (0,5 point). 
   Votre programme devrait inclure des commentaires, un échange (printf) avec l’utilisateur et 
   une gestion intelligente de la mémoire qui devrait être libérée à la fin du programme 
   (aucune fuite de mémoire) (0,25 point). 
   Enfin, votre programme se doit d’être facilement extensible et modifiable 
   (notamment en ce qui concerne la variable data) (0,25 point). */
   int data = 0;
   printf("%d", data);
   return 0;
}

